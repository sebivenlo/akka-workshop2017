package nl.fontys.sebi.recipes;

/**
 * This wouldn't be a serious restaurant without hamburger.
 *
 * @author Tobias Derksen <tobias.derksen@student.fontys.nl>
 */
public class Hamburger extends AbstractRecipe {

    @Override
    public int getCookingTime() {
        return 2;
    }
    
}

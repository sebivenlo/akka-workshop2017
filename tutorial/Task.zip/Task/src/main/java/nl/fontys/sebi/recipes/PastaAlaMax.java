package nl.fontys.sebi.recipes;

/**
 * Max´s special pasta, are you brave enough?
 * 
 * @author Tobias Derksen <tobias.derksen@student.fontys.nl>
 */
public class PastaAlaMax extends AbstractRecipe {

    @Override
    public int getCookingTime() {
        return 2;
    }
    
}
